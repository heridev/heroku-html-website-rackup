function swapImages(){
  var $active = $('#home-page-slider .active');
  var $next = ($('#home-page-slider .active').next().length > 0) ? $('#home-page-slider .active').next() : $('#home-page-slider img:first');
  $active.fadeOut(500, function(){
    $active.removeClass('active');
    $next.fadeIn(500).addClass('active');
  });
}

$(function () {
  //homepage slider
  setInterval('swapImages()', 5000);
});

